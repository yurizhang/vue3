import { createApp } from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

const APP=createApp(App);
// dont write: const APP=createApp(App).use(store).use(router).mount('#app');
APP.config.globalProperties.$trend = {trend:"test"};
APP.config.performance=true;
APP.use(store).use(router).mount('#app');
declare const window: Window & { APP: any}
window.APP=APP;
// window.APP=APP;
console.log(APP);

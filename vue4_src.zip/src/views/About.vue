<template>
  <div class="about">
    <h1>This is an about page</h1>
    <h3>vuex: {{$store.state.text}}</h3>
    <button @click="changeStore">changeStore</button>
  </div>
</template>
<script>

export default {
  methods: {
    changeStore(){
      this.$store.dispatch('checkText','异步修改commit修改');
    }
  },
}
</script>